import React from "react";

export default function botao(){
    return(
        <section className="sectionbotao">
        <button className="botao" onClick={function botao(){ alert("olá")}}>Clique</button>
        </section>
    )
}