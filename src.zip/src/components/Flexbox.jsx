import React from "react";

export default function Flexbox(){
    return(
        <section className="itens" >
            
            <div className="palavra" ><p>item 1</p></div>
            <div className="palavra2"><p>item 2</p></div>
            <div className="palavra3"><p>item 3</p></div>
        </section>
    )
}